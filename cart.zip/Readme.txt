------------------------------------------------------------------------------------------
Hi, Thanks for purchase our item ImmiEx - Immigration and Visa Consulting Website Template
------------------------------------------------------------------------------------------


Included:

	HTML (9 Layout Styles + 15 Additional Inner Pages) 10 predefined color schemes in each layout
	Documentation (Template Help Documentation)

-----------------------------------------------------------------------------------------
Features:
-----------------------------------------------------------------------------------------


	Fully Responsive Layout (PC, Tablet and Mobile phone)
	Based on Twitter Bootstrap 4.3.1
	jQuery-3.3.1
	12 Columns Grid System
	HTML5/CSS3 W3C valid
	Clean and Ultra Modern Design
	10 Predefined Amazing Color Schemes in each layout
	9 Layout Styles
	15 Additional Inner Pages
	Seo Optimized for Search Engine
	Google Analytics Ready	
	Modern Responsive Mobile Navigation
	Flaticon 200+ Vector Icons
	Font Awesome Retina Ready 675+ Vector Icons v5.7.2
	Working PHP Contact Form and Register Forms
	Contact Form and Register Forms Validation
	Working MailChimp Subscribe Form
	MailChimp Form Validation
	Over 600 Google web fonts you can use
	and much more ...

		
-----------------------------------------------------------------------------------------


Best Regards
Jthemes

http://themeforest.net/user/Jthemes

