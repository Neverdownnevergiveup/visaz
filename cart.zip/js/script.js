// Function to display the logout confirmation modal
function confirmLogout() {
    document.getElementById('logoutModal').style.display = 'block';
}

// Function to close the logout confirmation modal
function closeLogoutModal() {
    document.getElementById('logoutModal').style.display = 'none';
}

// Function to perform logout (can be customized to clear session or redirect)
function logout() {
    // Add logic to handle logout (e.g., clear session, localStorage, etc.)
    // For example, redirect to the logout page:
    window.location.href = "logout.html";
}
